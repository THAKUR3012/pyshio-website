"""Medicine courses: who is on which medicine until when, refill predictions and pharmacy demand forecast.

This file: logic and queries.
"""
from __future__ import annotations

import math
from datetime import datetime, timedelta

from shared import settings


def record_courses(conn, order_id: str, started=None) -> int:
    """Note when each handed-over medicine will run out (refill reminders, course tracking, demand forecasts)."""
    started = started or settings.now().date()
    rows = conn.execute(
        "SELECT oi.*, o.patient_id, o.pharmacy_id, o.prescription_id, r.lat, r.lng, pi.daily_units, pi.duration_days, "
        "pi.is_long_term, pi.quantity AS prescribed, COALESCE(m.generic_name, pi.generic_name) AS generic, "
        "COALESCE(m.strength, pi.strength) AS item_strength "
        "FROM order_items oi JOIN medicine_orders o ON o.id = oi.order_id "
        "JOIN prescriptions r ON r.id = o.prescription_id "
        "JOIN prescription_items pi ON pi.id = oi.prescription_item_id "
        "LEFT JOIN medicines m ON m.id = oi.medicine_id WHERE oi.order_id = ?", (order_id,)).fetchall()
    for r in rows:
        if r["daily_units"]:
            days = math.ceil(r["quantity"] / r["daily_units"])
        else:
            days = r["duration_days"]
        ends = (started + timedelta(days=days)).isoformat() if days else None
        conn.execute("INSERT OR IGNORE INTO courses (order_id, prescription_id, prescription_item_id, patient_id, "
                     "pharmacy_id, medicine_id, name, generic_name, strength, units, daily_units, is_long_term, "
                     "started_on, ends_on, lat, lng) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                     (order_id, r["prescription_id"], r["prescription_item_id"], r["patient_id"], r["pharmacy_id"],
                      r["medicine_id"], r["name"], r["generic"], r["item_strength"], r["quantity"], r["daily_units"],
                      r["is_long_term"], started.isoformat(), ends, r["lat"], r["lng"]))
    return len(rows)


def course_status(course, today: str, refilled: bool) -> str:
    if not course["ends_on"]:
        return "open"
    if course["ends_on"] < today:
        if not course["is_long_term"]:
            return "completed"
        return "refilled" if refilled else "overdue"
    soon = (datetime.fromisoformat(today) + timedelta(days=7)).date().isoformat()
    return "ending" if course["ends_on"] <= soon else "active"


def medicine_key(generic, name, strength) -> tuple:
    return ((generic or name or "").strip().lower(), (strength or "").strip().lower())


def courses_view(conn, where: str, params: tuple, include_patient: bool) -> list:
    rows = conn.execute(
        "SELECT c.*, u.name AS patient_name, u.phone AS patient_phone, r.reference, "
        "COALESCE(r.parent_id, r.id) AS root_id, ph.store_name FROM courses c "
        "JOIN users u ON u.id = c.patient_id JOIN prescriptions r ON r.id = c.prescription_id "
        "JOIN pharmacies ph ON ph.user_id = c.pharmacy_id "
        f"WHERE {where} ORDER BY c.ends_on IS NULL, c.ends_on", params).fetchall()
    # A long-term course counts as refilled once the same patient got the same medicine again later
    latest = {}
    for r in conn.execute(f"SELECT patient_id, generic_name, name, strength, MAX(started_on) AS last FROM courses "
                          f"WHERE patient_id IN ({','.join('?' * len({r['patient_id'] for r in rows}))}) "
                          "GROUP BY patient_id, lower(COALESCE(generic_name, name)), lower(COALESCE(strength, ''))",
                          tuple({r["patient_id"] for r in rows})) if rows else []:
        latest[(r["patient_id"], medicine_key(r["generic_name"], r["name"], r["strength"]))] = r["last"]
    today = settings.now().date().isoformat()
    out = []
    for r in rows:
        refilled = latest.get((r["patient_id"], medicine_key(r["generic_name"], r["name"], r["strength"])), "") > r["started_on"]
        item = {k: r[k] for k in ("id", "order_id", "prescription_id", "name", "generic_name", "strength", "units",
                                  "daily_units", "started_on", "ends_on", "reference", "store_name")}
        item.update(is_long_term=bool(r["is_long_term"]), status=course_status(r, today, refilled))
        root = conn.execute("SELECT * FROM prescriptions WHERE id = ?", (r["root_id"],)).fetchone()
        item["refills_left"] = max(root["refills_allowed"] - root["refills_used"], 0) if root["refills_allowed"] else 0
        if include_patient:
            item.update(patient_name=r["patient_name"], patient_phone=r["patient_phone"])
        out.append(item)
    return out


FORECAST_LOOKBACK_DAYS = 28
