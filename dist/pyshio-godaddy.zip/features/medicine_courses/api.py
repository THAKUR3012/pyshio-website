"""Medicine courses: who is on which medicine until when, refill predictions and pharmacy demand forecast.

This file: HTTP endpoints and request models.
"""
import math
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, Query
from typing import Optional

from shared import geo, settings
from shared.auth import patient_user, pharmacy_user
from shared.common import stamp
from shared.db import get_db

router = APIRouter()


@router.get("/api/pharmacy/courses")
def pharmacy_courses(status: Optional[str] = None, user: dict = Depends(pharmacy_user)):
    """This pharmacy's own customers: who is on long-term medicines and when they'll need more."""
    since = (settings.now().date() - timedelta(days=120)).isoformat()
    with get_db() as conn:
        rows = courses_view(conn, "c.pharmacy_id = ? AND (c.is_long_term = 1 OR c.started_on >= ?)",
                            (user["id"], since), include_patient=True)
    counts = {}
    for r in rows:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    if status:
        rows = [r for r in rows if r["status"] == status]
    return {"courses": rows, "counts": counts}


@router.get("/api/my/courses")
def my_courses(user: dict = Depends(patient_user)):
    with get_db() as conn:
        return courses_view(conn, "c.patient_id = ?", (user["id"],), include_patient=False)


@router.get("/api/pharmacy/forecast")
def pharmacy_forecast(days: int = Query(7, ge=1, le=90), user: dict = Depends(pharmacy_user)):
    """Estimated demand near the store: recent prescribing rate plus long-term courses running out soon."""
    now = settings.now()
    today = now.date()
    with get_db() as conn:
        pharmacy = get_pharmacy(conn, user["id"])
        radius = max(settings.NEARBY_RADIUS_KM, pharmacy["delivery_radius_km"] or 0)
        min_lat, max_lat, min_lng, max_lng = geo.bounding_box(pharmacy["lat"], pharmacy["lng"], radius)
        since = stamp(now - timedelta(days=FORECAST_LOOKBACK_DAYS))
        trend_since = stamp(now - timedelta(weeks=8))
        rx_rows = conn.execute(
            "SELECT r.id, r.lat, r.lng, r.created_at FROM prescriptions r WHERE r.status != 'cancelled' "
            "AND r.created_at >= ? AND r.lat BETWEEN ? AND ? AND r.lng BETWEEN ? AND ?",
            (trend_since, min_lat, max_lat, min_lng, max_lng)).fetchall()
        near = {r["id"]: r["created_at"] for r in rx_rows
                if geo.haversine_km(pharmacy["lat"], pharmacy["lng"], r["lat"], r["lng"]) <= radius}
        demand, weekly = {}, [0] * 8
        ids = list(near)
        for chunk in range(0, len(ids), 500):
            part = ids[chunk:chunk + 500]
            for i in conn.execute(
                    f"SELECT i.prescription_id, i.name, i.quantity, COALESCE(m.generic_name, i.generic_name) AS generic, "
                    f"COALESCE(m.strength, i.strength) AS strength FROM prescription_items i "
                    f"LEFT JOIN medicines m ON m.id = i.medicine_id WHERE i.prescription_id IN ({','.join('?' * len(part))})",
                    part):
                created = near[i["prescription_id"]]
                week = min(7, max(0, (now - datetime.fromisoformat(created)).days // 7))
                weekly[7 - week] += i["quantity"]
                if created < since:
                    continue
                d = demand.setdefault(medicine_key(i["generic"], i["name"], i["strength"]),
                                      {"generic_name": i["generic"] or i["name"], "strength": i["strength"],
                                       "brands": {}, "prescriptions": set(), "units": 0, "refill_units": 0})
                d["units"] += i["quantity"]
                d["prescriptions"].add(i["prescription_id"])
                d["brands"][i["name"]] = d["brands"].get(i["name"], 0) + 1
        # Long-term courses nearby that run out inside the window will need a refill
        until = (today + timedelta(days=days)).isoformat()
        for c in conn.execute("SELECT * FROM courses WHERE is_long_term = 1 AND ends_on >= ? AND ends_on <= ? "
                              "AND lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?",
                              (today.isoformat(), until, min_lat, max_lat, min_lng, max_lng)):
            if geo.haversine_km(pharmacy["lat"], pharmacy["lng"], c["lat"], c["lng"]) > radius:
                continue
            d = demand.setdefault(medicine_key(c["generic_name"], c["name"], c["strength"]),
                                  {"generic_name": c["generic_name"] or c["name"], "strength": c["strength"],
                                   "brands": {}, "prescriptions": set(), "units": 0, "refill_units": 0})
            d["refill_units"] += c["units"]
        stock = {}
        for s_row in conn.execute(STOCK_SELECT + " WHERE s.pharmacy_id = ?", (user["id"],)):
            key = medicine_key(s_row["generic_name"], s_row["name"], s_row["strength"])
            stock[key] = stock.get(key) or bool(s_row["in_stock"])
    rows = []
    for key, d in demand.items():
        expected = math.ceil(d["units"] / FORECAST_LOOKBACK_DAYS * days + d["refill_units"])
        if key in stock:
            stock_status = "in_stock" if stock[key] else "out_of_stock"
        else:
            stock_status = "not_listed"
        rows.append({"generic_name": d["generic_name"], "strength": d["strength"],
                     "brands": [b for b, _ in sorted(d["brands"].items(), key=lambda x: -x[1])[:3]],
                     "prescriptions_recent": len(d["prescriptions"]), "units_recent": d["units"],
                     "refill_units": d["refill_units"], "expected_units": expected, "stock_status": stock_status,
                     "stock_up": expected >= 5 and stock_status != "in_stock"})
    rows.sort(key=lambda r: (-r["expected_units"], r["generic_name"]))
    week_starts = [(today - timedelta(weeks=7 - n, days=today.weekday())).isoformat() for n in range(8)]
    return {"days": days, "radius_km": radius, "lookback_days": FORECAST_LOOKBACK_DAYS, "items": rows[:60],
            "stock_up": sum(r["stock_up"] for r in rows), "weekly_units": [
                {"week": week_starts[n], "units": weekly[n]} for n in range(8)]}


# Imported last, so slices can depend on each other in any order
from features.medicine_courses.logic import courses_view, FORECAST_LOOKBACK_DAYS, medicine_key  # noqa: E402
from features.medicines.logic import STOCK_SELECT  # noqa: E402
from features.pharmacies.logic import get_pharmacy  # noqa: E402
